package kr.co.sist.e_learning.admin.auth;


import org.springframework.stereotype.Repository;

@Repository
public class AdminAuthDAOImpl implements AdminAuthDAO {



	@Override
	public AdminAuthDTO loginSelectAdminById(String id) {
		// TODO Auto-generated method stub
		return null;
	}
}

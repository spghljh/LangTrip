package kr.co.sist.e_learning.support;

public interface SupportDTOIdentifier {
	String getId();
}
